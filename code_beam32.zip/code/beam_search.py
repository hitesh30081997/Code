"""
beam_search.py
Batched beam search for the teacher-shaped Transformer decoder
(embedding -> TransformerDecoder -> classifier). Works for BOTH the HuBERT
student (model_seq.py) and the NeMo teacher, because they share these modules.

    hyps = beam_search_modules(emb, dec, cls, enc, enc_mask, bos, eos,
                               beam_size=32, max_len=128, length_penalty=1.0)
    hyps[b] -> list of (token_ids, score) sorted best-first (BOS/EOS stripped)

Scoring
-------
Hypotheses are searched with the raw sum of token log-probs. Finished
hypotheses stay in the beam (they can only emit EOS at cost 0), which makes the
search exact w.r.t. the unnormalised score. The final N-best is re-ranked with
the GNMT length penalty  lp(L) = ((5 + L) / 6) ** alpha  (alpha=0 disables it),
so long semantics strings with several entities are not unfairly penalised.
"""
import torch


def _unwrap(x):
    return x[0] if isinstance(x, (tuple, list)) else x


def make_step_fn(embedding, decoder, classifier):
    """Returns step(ys, enc, enc_mask) -> log-probs of the NEXT token, (N, V).
    The full prefix is re-run each step (no KV cache) so it works unchanged
    across NeMo 1.x / 2.x decoder APIs."""
    def step(ys, enc, enc_mask):
        h = embedding(ys)
        h = _unwrap(decoder(h, torch.ones_like(ys, dtype=torch.float), enc, enc_mask))
        logits = classifier(hidden_states=h[:, -1:]).float().squeeze(1)
        return torch.log_softmax(logits, dim=-1)  # idempotent if already log-probs
    return step


def length_penalty_fn(lengths, alpha):
    if alpha == 0.0:
        return torch.ones_like(lengths, dtype=torch.float)
    return ((5.0 + lengths.float()) / 6.0) ** alpha


@torch.no_grad()
def beam_search(step_fn, enc, enc_mask, bos_id, eos_id, beam_size=32, max_len=128,
                length_penalty=1.0, nbest=1):
    """
    enc: (B, T, D)  enc_mask: (B, T) float/bool (1 = valid frame)
    Returns a list (len B) of lists of (ids, score) with up to `nbest` entries.
    """
    B, T, D = enc.shape
    K = beam_size
    dev = enc.device
    neg_inf = float("-inf")

    enc_k = enc.unsqueeze(1).expand(B, K, T, D).reshape(B * K, T, D)
    mask_k = enc_mask.unsqueeze(1).expand(B, K, T).reshape(B * K, T)

    ys = torch.full((B * K, 1), bos_id, dtype=torch.long, device=dev)
    scores = torch.full((B, K), neg_inf, device=dev)
    scores[:, 0] = 0.0                         # only one live beam at t=0
    finished = torch.zeros(B, K, dtype=torch.bool, device=dev)
    lengths = torch.zeros(B, K, dtype=torch.long, device=dev)  # tokens incl. EOS

    for _ in range(max_len):
        logp = step_fn(ys, enc_k, mask_k)      # (B*K, V)
        V = logp.shape[-1]
        logp = logp.view(B, K, V)
        # finished beams: only EOS allowed, at zero cost -> score unchanged
        fin_row = torch.full((V,), neg_inf, device=dev)
        fin_row[eos_id] = 0.0
        logp = torch.where(finished.unsqueeze(-1), fin_row.view(1, 1, V), logp)

        cand = (scores.unsqueeze(-1) + logp).view(B, K * V)
        top_s, top_i = cand.topk(K, dim=-1)    # (B, K)
        beam_i = top_i // V
        tok = top_i % V

        gather = (beam_i + torch.arange(B, device=dev).unsqueeze(1) * K).view(-1)
        ys = torch.cat([ys[gather], tok.view(-1, 1)], dim=1)
        prev_fin = finished.gather(1, beam_i)
        lengths = lengths.gather(1, beam_i) + (~prev_fin).long()
        finished = prev_fin | (tok == eos_id)
        scores = top_s
        if bool(finished.all()):
            break

    norm = scores / length_penalty_fn(lengths, length_penalty)
    norm = torch.where(torch.isfinite(norm), norm, torch.full_like(norm, neg_inf))
    order = norm.argsort(dim=-1, descending=True)
    ys = ys[:, 1:].view(B, K, -1)

    out = []
    for b in range(B):
        hyps, seen = [], set()
        for k in order[b].tolist():
            s = float(norm[b, k])
            if s == neg_inf:
                break
            row = ys[b, k].tolist()
            row = row[: row.index(eos_id)] if eos_id in row else row
            key = tuple(row)
            if key in seen:
                continue
            seen.add(key)
            hyps.append((row, s))
            if len(hyps) >= nbest:
                break
        out.append(hyps or [([], neg_inf)])
    return out


def beam_search_modules(embedding, decoder, classifier, enc, enc_mask, bos_id, eos_id, **kw):
    return beam_search(make_step_fn(embedding, decoder, classifier), enc, enc_mask,
                       bos_id, eos_id, **kw)
