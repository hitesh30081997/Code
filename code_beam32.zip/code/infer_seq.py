"""
infer_seq.py
Run the trained HuBERT student. Output format is identical to the NeMo teacher.

    python infer_seq.py --ckpt ckpt_seq_kd/best_student.pt audio1.flac audio2.wav
    python infer_seq.py --ckpt ckpt_seq_kd/best_student.pt --compare_teacher audio1.flac
    python infer_seq.py --ckpt ckpt_seq_kd/best_student.pt --beam_size 32 --nbest 5 audio1.flac
    python infer_seq.py --ckpt ckpt_seq_kd/best_student.pt --beam_size 1 audio1.flac   # greedy

The teacher .nemo is loaded for the decoder architecture and tokenizer (and,
with --compare_teacher, to print the teacher's output next to the student's).
"""
import argparse

import torch

from kd_dataset import load_mono
from model_seq import HubertSemanticSLU
from teacher_nemo import (DEFAULT_NEMO_PATH, download_teacher, load_teacher_model,
                          parse_semantics, _unwrap)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", required=True)
    p.add_argument("--teacher_nemo", default=DEFAULT_NEMO_PATH)
    p.add_argument("--compare_teacher", action="store_true")
    p.add_argument("--max_decode_len", type=int, default=128)
    p.add_argument("--beam_size", type=int, default=None, help="default: value saved in ckpt, else 32")
    p.add_argument("--length_penalty", type=float, default=None)
    p.add_argument("--nbest", type=int, default=1, help="print the top-N beam hypotheses")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("audio", nargs="+")
    args = p.parse_args()

    teacher = load_teacher_model(download_teacher(args.teacher_nemo), args.device)
    tok = teacher.tokenizer
    ckpt = torch.load(args.ckpt, map_location="cpu", weights_only=False)
    cfg = ckpt["config"]
    student = HubertSemanticSLU(
        teacher, hubert_name=cfg["hubert_name"], layer_fusion=cfg["layer_fusion"],
        semantic_layer=cfg["semantic_layer"],
        fusion_layers=[int(x) for x in cfg["fusion_layers"].split(",")] if cfg["fusion_layers"] else None,
        adapter_layers=cfg["adapter_layers"],
    )
    student.load_state_dict(ckpt["state_dict"])
    student.to(args.device).eval()
    beam = args.beam_size if args.beam_size is not None else cfg.get("beam_size", 32)
    lp = args.length_penalty if args.length_penalty is not None else cfg.get("length_penalty", 1.0)
    print(f"[decode] beam_size={beam} length_penalty={lp}")

    for path in args.audio:
        wav = torch.from_numpy(load_mono(path)).unsqueeze(0).to(args.device)
        att = torch.ones_like(wav, dtype=torch.long)
        dec = lambda x: "".join(tok.tokenizer.decode_ids(list(x)))
        if beam <= 1:
            hyps = [(student.greedy(wav, att, tok.bos_id, tok.eos_id, max_len=args.max_decode_len)[0], 0.0)]
        else:
            hyps = student.beam_search(wav, att, tok.bos_id, tok.eos_id, beam_size=beam,
                                       max_len=args.max_decode_len, length_penalty=lp,
                                       nbest=max(1, args.nbest), return_scores=True)[0]
        text = dec(hyps[0][0])
        print(f"\n{path}\n  student: {text}")
        for r, (ids, sc) in enumerate(hyps[1:args.nbest], start=2):
            print(f"  #{r} ({sc:.2f}): {dec(ids)}")
        if args.compare_teacher:
            with torch.no_grad():
                from nemo.collections.asr.parts.utils.slu_utils import get_seq_mask
                lens = torch.tensor([wav.shape[1]], device=args.device)
                f, fl = teacher.preprocessor(input_signal=wav, length=lens)
                enc, el = teacher.encoder(audio_signal=f, length=fl)
                enc = enc.transpose(1, 2)
                if beam <= 1:
                    sg = teacher.sequence_generator
                    t = sg.decode_semantics_from_tokens(_unwrap(sg(enc, get_seq_mask(enc, el))))[0]
                else:
                    from beam_search import beam_search_modules
                    h = beam_search_modules(teacher.embedding, teacher.decoder, teacher.classifier,
                                            enc, get_seq_mask(enc, el).float(), tok.bos_id, tok.eos_id,
                                            beam_size=beam, max_len=args.max_decode_len,
                                            length_penalty=lp)
                    t = dec(h[0][0][0])
            print(f"  teacher: {t}")
        print(f"  parsed : {parse_semantics(text)}")


if __name__ == "__main__":
    main()
